import { ExternalLink, Github } from "lucide-react";
import Link from "next/link";

const projects = [
  {
    title: "Project Alpha",
    description:
      "A revolutionary platform that transforms how businesses handle customer relationships through AI-powered insights.",
    tags: ["React", "Node.js", "AI/ML", "PostgreSQL"],
    github: "https://github.com/eshelnagar/project-alpha",
    live: "#",
  },
  {
    title: "DevFlow",
    description:
      "Developer productivity tool that streamlines workflow automation and team collaboration for modern engineering teams.",
    tags: ["TypeScript", "Next.js", "Prisma", "Tailwind"],
    github: "https://github.com/eshelnagar/devflow",
    live: "#",
  },
  {
    title: "QuickLaunch",
    description:
      "A startup toolkit that helps founders go from idea to MVP in record time with pre-built templates and integrations.",
    tags: ["React", "Firebase", "Stripe", "Vercel"],
    github: "https://github.com/eshelnagar/quicklaunch",
    live: "#",
  },
  {
    title: "DataSync",
    description:
      "Real-time data synchronization platform that keeps your applications in perfect harmony across multiple services.",
    tags: ["Go", "Redis", "WebSockets", "Docker"],
    github: "https://github.com/eshelnagar/datasync",
    live: "#",
  },
];

export function Projects() {
  return (
    <section id="projects" className="py-24 px-6 md:px-12 lg:px-24 bg-card">
      <div className="max-w-6xl mx-auto">
        <div className="flex items-center gap-4 mb-12">
          <div className="w-12 h-px bg-primary" />
          <span className="text-primary font-mono text-sm tracking-wider uppercase">
            Projects
          </span>
        </div>

        <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
          Things I&apos;ve Built
        </h2>
        <p className="text-muted-foreground text-lg mb-12 max-w-2xl">
          A selection of projects that showcase my skills and passion for
          building innovative solutions.
        </p>

        <div className="grid md:grid-cols-2 gap-6">
          {projects.map((project) => (
            <div
              key={project.title}
              className="group bg-secondary/50 border border-border rounded-xl p-6 hover:border-primary/50 transition-all duration-300"
            >
              <div className="flex items-start justify-between mb-4">
                <h3 className="text-xl font-semibold text-foreground group-hover:text-primary transition-colors">
                  {project.title}
                </h3>
                <div className="flex items-center gap-3">
                  <Link
                    href={project.github}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-primary transition-colors"
                    aria-label={`GitHub repository for ${project.title}`}
                  >
                    <Github className="w-5 h-5" />
                  </Link>
                  <Link
                    href={project.live}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="text-muted-foreground hover:text-primary transition-colors"
                    aria-label={`Live demo of ${project.title}`}
                  >
                    <ExternalLink className="w-5 h-5" />
                  </Link>
                </div>
              </div>

              <p className="text-muted-foreground mb-6 leading-relaxed">
                {project.description}
              </p>

              <div className="flex flex-wrap gap-2">
                {project.tags.map((tag) => (
                  <span
                    key={tag}
                    className="text-xs font-mono text-primary bg-primary/10 px-3 py-1 rounded-full"
                  >
                    {tag}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>

        <div className="mt-12 text-center">
          <Link
            href="https://github.com/eshelnagar"
            target="_blank"
            rel="noopener noreferrer"
            className="inline-flex items-center gap-2 text-primary hover:underline font-medium"
          >
            View more on GitHub
            <ExternalLink className="w-4 h-4" />
          </Link>
        </div>
      </div>
    </section>
  );
}
